﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TelChina.AF.Service.AOP;
using System.Linq.Expressions;

namespace $rootnamespace$
{
    [ServiceContract]
    [PolicyInjectionBehavior] //提供PIAB接口
    public interface $safeitemname$
    {        
        /// <summary>
        /// 操作
        /// </summary>
        /// <param name="param"></param>
        [OperationContract]
        //允许接收来自客户端事务流
        [TransactionFlow(TransactionFlowOption.Allowed)]
        //如果客户端传入了事务,则沿用,否则新建事务   
        bool DO();
    }
}

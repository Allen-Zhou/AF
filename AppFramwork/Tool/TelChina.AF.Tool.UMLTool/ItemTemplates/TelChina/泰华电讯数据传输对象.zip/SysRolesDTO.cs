﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace $rootnamespace$
{
    [DataContract]
    [Serializable]
    public class $safeitemname$
    {
        [DataMember]
        public Guid ID
        {
            get;
            set;
        }
        [DataMember]
        public DateTime CreatedOn
        {
            get;
            set;
        }
        [DataMember]
        public string CreatedBy
        {
            get;
            set;
        }
        [DataMember]
        public DateTime UpdatedOn
        {
            get;
            set;
        }
        [DataMember]
        public string UpdatedBy
        {
            get;
            set;
        }
        [DataMember]
        public int SysVersion
        {
            get;
            set;
        }
    }
}

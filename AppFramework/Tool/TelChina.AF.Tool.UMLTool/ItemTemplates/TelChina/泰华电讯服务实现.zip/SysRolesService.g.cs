﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using TelChina.AF.Sys.Service;

namespace $rootnamespace$
{
    public partial class $safeitemname$ : ServiceBase, I$safeitemname$
    {       
        /// <summary>
        /// 是否存在
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public bool DO()
        {
            return base.ServiceInvoke<bool>(DO_Extend);
        }
    }
}

﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TelChina.AF.Persistant;

namespace $rootnamespace$
{
    public partial class $safeitemname$  
    {
        /// <summary>
        /// 是否存在
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        private bool DO_Extend()
        {
            return true;
        }
    }
}
